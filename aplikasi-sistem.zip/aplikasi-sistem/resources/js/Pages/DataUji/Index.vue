<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, Link, useForm, usePage } from '@inertiajs/vue3';
import Modal from '@/Components/Modal.vue';
import { ref, watch, defineProps, onMounted, inject } from 'vue';
import axios from 'axios';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import DropdownLink from '@/Components/DropdownLink.vue';
import Dropdown from '@/Components/Dropdown.vue';
const swal = inject('$swal')

const page = usePage()

onMounted(() => {
    if (page.props.message !== null) {
        swal({
            icon: "info",
            title: 'Berhasil',
            text: page.props.message,
            showConfirmButton: true,
            timer: 2000
        });
    }
})
function messageDisplay(message, icon) {
    swal({
        icon: icon,
        title: 'Perhatian!!',
        text: message,
        showConfirmButton: true,
        timer: 2000
    });
}
const props = defineProps({
    search: {
        type: String,
        default: '',
    },
    order: {
        type: String,
        default: '',
    },
    date: {
        type: String,
        default: '',
    },
    penilaian: {
        type: Object,
        default: () => ({}),
    },
    table_colums: {
        type: Object,
        default: () => ({}),
    },
    can: {
        type: Object,
        default: () => ({}),
    },
})

const Form = useForm({
    search: props.search,
    date: props.date,
    order: props.order,
})

const search = ref(props.search)
const order = ref(props.order)
const date = ref(props.date)

// Filter By

watch(search, (value) => {
    Form.search = value
    Form.get(route('Datauji.index'), {
        preserveScroll: true,
        preserveState: true,
    })
})
watch(order, (value) => {
    Form.order = value
    Form.get(route('Datauji.index'), {
        preserveScroll: true,
        preserveState: true,
    })
})
watch(date, (value) => {
    Form.date = value
    Form.get(route('Datauji.index'), {
        preserveScroll: true,
        preserveState: true,
    })
})

function resetFilter() {
    search.value = '';
    date.value = '';
}
//
const crud = ref({
    tambah: props.can.add,
    edit: props.can.edit,
    show: props.can.show,
    delete: props.can.delete,
    reset_password: props.can.reset,

})
function cekAksi() {
    if (crud.value.tambah || crud.value.edit || crud.value.show || crud.value.delete) {
        return true;
    } else {
        return false;
    }
}

const showModal = ref(false);
const btnModal = ref(false);

const formpenilaian = useForm({
    slug: '',
    status: '',
    jam_pemeriksaan: '',
})

const getpenilaian = function (item) {
    showModal.value = true;
    formpenilaian.slug = item.id;
    formpenilaian.status = item.status;
    formpenilaian.jam_pemeriksaan = item.jam_pemeriksaan;
}

function submit() {
    formpenilaian.put(route('Datauji.update'), {
        preserveState: false,
        onError: (err) => {
            var ul = "";
            for (const key in err) {
                ul += err[key] + '\n';

            }
            // err.forEach((element,key)=>{
            // })
            messageDisplay(ul, 'error');
        },
        onFinish: () => {
            showModal.value = false;
        }

    })
}
</script>

<template>

    <Head title="penilaian" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-900 leading-tight">Data penilaian</h2>
        </template>


        <div class="py-4 relative box-content">
            <div class="w-full overflow-hidden rounded-lg shadow-xs divide-y divide-gray-700 bg-white">
                <div class="py-3 px-4 flex justify-between">
                    <div class="flex gap-4">
                        <!-- <div class="relative max-w-xs">
                            <label class="sr-only">Search</label>
                            <input type="search" name="hs-table-with-pagination-search"
                                id="hs-table-with-pagination-search" v-model="search"
                                class="pl-2 py-1 md:pl-8 md:py-2 ps-9 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none"
                                placeholder="Cari Data.........">
                            <div class="absolute inset-y-0 start-0 flex items-center pointer-events-none ps-3">
                                <svg class="size-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="24"
                                    height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="11" cy="11" r="8"></circle>
                                    <path d="m21 21-4.3-4.3"></path>
                                </svg>
                            </div>
                        </div> -->
                        <div class="relative max-w-xs">
                            <label class="sr-only">Tanggal penilaian</label>
                            <input type="date" name="hs-table-with-pagination-date" id="hs-table-with-pagination-date"
                                v-model="date"
                                class="py-1 md:py-2 ps-9 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none">
                        </div>
                        <div class="relative max-w-xs">
                            <button type="reset" @click="resetFilter()"
                                class="py-1 md:py-2 border px-2 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none">Reset</button>
                        </div>
                    </div>
                    <div class="relative max-w-xs flex items-center gap-2">
                        <label class="capitalize text-xs md:text-sm">Urutkan</label>

                        <select id="order" v-model="order"
                            class="px-2 py-1 md:px-3 md:py-2 placeholder-gray-400 border focus:outline-none sm:w-40 sm:text-sm border-gray-200 shadow-sm rounded-lg focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none ">
                            <option value="">-----</option>
                            <option value="desc">Terbaru</option>
                            <option value="asc">Terlama</option>
                        </select>
                        <div class="absolute inset-y-0 end-3 flex items-center pointer-events-none ps-3">
                            <font-awesome-icon :icon="['fas', 'filter']" class="text-gray-400" />
                        </div>
                    </div>
                </div>
                <div class="w-full overflow-x-auto">
                    <table class="w-full whitespace-no-wrap">
                        <colgroup>
                        <col>
                        <col>
                        <col>
                        </colgroup>
                        <thead>
                            <tr
                                class="text-xs font-semibold tracking-wide text-left uppercase border-b border-gray-700  text-gray-900 bg-white">
                                <th class="px-4 py-3">No</th>
                                <th class="px-4 py-3">Tgl</th>
                                <th class="px-4 py-3">Hasil</th>
                                <th scope="col" v-if="cekAksi()"
                                    class=" px-2 py-1 md:px-6 md:py-3 text-end text-xs font-medium text-gray-500 uppercase">
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody class=" divide-y divide-gray-700 bg-white" v-if="penilaian.data.length"
                            :class="{ 'opacity-75 blur-sm': Form.processing }">
                            <tr class="text-gray-900" v-for="(item, index) in penilaian.data">
                                <td class="px-4 py-3">
                                    {{ (penilaian.current_page - 1) * penilaian.per_page + index + 1 }}
                                </td>
                                <td class="px-4 py-3 text-sm">
                                    {{ item.tgl_uji }}
                                </td>
                                <td class="px-4 py-3 text-sm">
                                    <table>
                                        <tr>
                                            <th scope="col"
                                                class="px-2 py-1 border md:px-6 md:py-3 text-nowrap text-start text-xs font-medium text-gray-700 uppercase">
                                                Alternatif
                                            </th>
                                            <th scope="col"
                                                class="px-2 py-1 border md:px-6 md:py-3 text-nowrap text-start text-xs font-medium text-gray-700 uppercase">
                                                Nilai
                                            </th>
                                            <th scope="col"
                                                class="px-2 py-1 border md:px-6 md:py-3 text-nowrap text-start text-xs font-medium text-gray-700 uppercase">
                                                Ranking
                                            </th>
                                        </tr>
                                        <tr v-for="(col, idx, n) in item.hasil" :key="col.id">
                                            <td class="px-2 py-1 text-sm border text-center font-medium text-gray-800">{{
                                                idx }}
                                            </td>
                                            <td class="px-2 py-1 text-sm border text-center font-medium text-gray-800">{{
                                                col }}
                                            </td>
                                            <td class="px-2 py-1 text-sm border text-center font-medium text-gray-800">{{
                                                n + 1 }}
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td class="relative px-2 py-1 md:px-6 md:py-3 whitespace-nowrap text-end text-sm font-medium"
                                    v-if="cekAksi()">
                                    <!-- Settings Dropdown -->
                                    <div class="ml-3">
                                        <Dropdown align="top" width="48">
                                            <template #trigger>
                                                <span class="inline-flex rounded-md">
                                                    <button type="button"
                                                        class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                                        Aksi

                                                        <font-awesome-icon :icon="['fas', 'ellipsis-vertical']"
                                                            class="ml-2 -mr-0.5 h-4 w-4" />

                                                    </button>
                                                </span>
                                            </template>

                                            <template #content>
                                                <DropdownLink v-if="crud.edit"
                                                    :href="route('Datauji.edit', { slug: item.id })"
                                                    class="flex justify-start gap-3">
                                                    <font-awesome-icon class="text-orange-500 hover:text-orange-700"
                                                        :icon="['fas', 'pen-to-square']" />
                                                    Edit
                                                </DropdownLink>
                                                <DropdownLink v-if="crud.show"
                                                    :href="route('Datauji.show', { slug: item.id })"
                                                    class="flex justify-start gap-3">
                                                    <font-awesome-icon class="text-blue-500 hover:text-blue-700"
                                                        :icon="['fas', 'eye']" />
                                                    Detail
                                                </DropdownLink>
                                                <button type="button" v-if="crud.delete" @click="showDeleteModal(item)"
                                                    class="flex justify-start gap-3 w-full px-4 py-1 text-start text-sm leading-5 text-gray-700 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 transition duration-150 ease-in-out">
                                                    <font-awesome-icon class="text-red-500 hover:text-red-700"
                                                        :icon="['fas', 'trash-can']" />
                                                    hapus
                                                </button>


                                                <DropdownLink v-if="crud.reset_password"
                                                    :href="route('Datauji.reset.password', { slug: item.user.id })"
                                                    class="flex justify-start gap-3">
                                                    <font-awesome-icon class="text-blue-500 hover:text-blue-700"
                                                        :icon="['fas', 'key']" />
                                                    Reset Password
                                                </DropdownLink>
                                            </template>
                                        </Dropdown>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                        <tbody class="divide-y divide-gray-700 bg-gray-200" v-else>
                            <tr>
                                <td colspan="7" class="p-5 text-gray-900 text-center">Data Kosong</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="py-1 px-4 ">
                    <div class="flex flex-wrap">
                        <template v-for="(link, key) in penilaian.links">
                            <div v-if="link.url === null" :key="key"
                                class="mb-1 mr-1 px-4 py-3 text-gray-900 text-sm leading-4 border rounded"
                                v-html="link.label" />
                            <Link v-else :key="`link-${key}`"
                                class="mb-1 mr-1 px-4 py-3 focus:text-indigo-500 text-sm leading-4 active:border-blue-400 hover:bg-gray-200 border focus:border-indigo-500 rounded"
                                :class="{ 'bg-white border-blue-500 text-black': link.active }" preserve-state
                                preserve-scroll :data="{ search, order }" :href="link.url" v-html="link.label" />
                        </template>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
