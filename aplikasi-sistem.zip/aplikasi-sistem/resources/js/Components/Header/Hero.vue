<template>
    <div
        class="flex flex-col md:flex-row items-center justify-center max-w-4xl relative  px-4 mx-auto md:py-5 md:px-8 ">

        <img :src="'/images/svg/hospital-building.svg'" class="w-full mx-auto object-contain md:w-1/2 relative "
            alt="" />
        <div class="max-w-lg mb-10 md:mx-auto  md:mb-12">

            <h2
                class="max-w-full mb-6 font-sans text-3xl font-bold leading-none tracking-tight text-gray-900 sm:text-4xl md:mx-auto">
                <span class="relative inline-block">
                    <svg viewBox="0 0 52 24" fill="currentColor"
                        class="absolute top-0 left-0 z-0 hidden w-32 -mt-8 -ml-20 text-blue-gray-100 lg:w-32 lg:-ml-28 lg:-mt-10 sm:block">
                        <defs>
                            <pattern id="9ef1ff62-feb2-41fe-8163-772b4c79de7b" x="0" y="0" width=".135" height=".30">
                                <circle cx="1" cy="1" r=".7"></circle>
                            </pattern>
                        </defs>
                        <rect fill="url(#9ef1ff62-feb2-41fe-8163-772b4c79de7b)" width="52" height="24"></rect>
                    </svg>
                </span>
                Temukan Lahan Terbaik untuk Budidaya Ikan Air Tawar dengan Prediksi TOPSIS
            </h2>

        </div>
    </div>
    <div class="container mx-auto p-8">
        <h1 class="text-3xl font-bold text-center mb-8">Selamat Datang di Lahan Ikan Anda!</h1>

        <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-8 mb-8">
            <h2 class="text-xl font-semibold mb-4">Mengapa Anda Membutuhkan SPK TOPSIS?</h2>
            <ul class="list-disc pl-6 mb-4">
                <li>Keputusan Lebih Cepat: Dengan SPK TOPSIS, Anda dapat menganalisis berbagai aspek lahan dengan cepat dan efisien.</li>
                <li>Pilihan yang Tepat: Sistem kami membantu Anda menemukan lahan yang paling sesuai dengan kebutuhan dan preferensi Anda.</li>
                <li>Optimalisasi Hasil: Dengan memilih lahan yang tepat, Anda dapat meningkatkan produktivitas dan hasil budidaya ikan Anda.</li>
            </ul>
        </div>

        <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-8 mb-8">
            <h2 class="text-xl font-semibold mb-4">Bagaimana Sistem Kami Bekerja?</h2>
            <ol class="list-decimal pl-6 mb-4">
                <li>Input Kriteria: Anda memberikan informasi tentang preferensi dan kebutuhan Anda, seperti luas lahan, kualitas air, aksesibilitas, dan lain-lain.</li>
                <li>Pengolahan Data: Sistem kami mengolah data yang Anda berikan dan melakukan perhitungan berdasarkan metode TOPSIS.</li>
                <li>Hasil yang Akurat: Anda akan menerima hasil yang jelas dan terperinci, termasuk peringkat lahan berdasarkan kriteria yang Anda tentukan.</li>
                <li>Rekomendasi: Kami memberikan rekomendasi yang sesuai dengan preferensi Anda, membantu Anda dalam pengambilan keputusan.</li>
            </ol>
        </div>

        <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-8 mb-8">
            <h2 class="text-xl font-semibold mb-4">Keuntungan Menggunakan Layanan Kami</h2>
            <ul class="list-disc pl-6 mb-4">
                <li>Efisiensi: Hemat waktu dan usaha dengan proses pengambilan keputusan yang lebih cepat.</li>
                <li>Ketepatan: Dapatkan lahan yang paling sesuai dengan kebutuhan Anda.</li>
                <li>Maksimalkan Hasil: Optimalisasikan produksi ikan Anda dengan memilih lahan yang tepat.</li>
                <li>Dukungan Penuh: Tim ahli kami siap membantu Anda setiap langkah dalam memilih lahan yang ideal.</li>
            </ul>
        </div>

    </div>
</template>
